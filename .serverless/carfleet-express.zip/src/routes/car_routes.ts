import { Application, Request, Response } from "express";
import * as AWS from "aws-sdk";

AWS.config.update({
  region: "us-east-1",
});

interface Position {
  lat: number;
  lon: number;
}

interface ICar {
  id: number;
  name: string;
  vin: string;
  make: string;
  model: string;
  year: string;
  fuelType: string;
  type: string;
  Position: Position;
  odometer: number;
  fuel: number;
  battery: number;
}

export class CarRoutes {
  private dynamodb = new AWS.DynamoDB();
  private docClient = new AWS.DynamoDB.DocumentClient();

  public route(app: Application) {
    app.get("/api/cars", (req: Request, res: Response) => {
      const dbParams = { TableName: "CarFleet" };
      let cars: ICar[];
      this.docClient.scan(dbParams, (err, cars) => {
        if (err) {
          return res.status(500).json({
            success: false,
            message: "Error: Server error",
          });
        } else {
          return {
            statusCode: 200,
            body: cars,
          };

          // res.send({

          //   success: true,
          //   message: "Loaded cars",
          //   cars: cars,
          // });
        }
      });
    });

    app.post("/api/cars", (req: Request, res: Response) => {
      let dbParams = {
        TableName: "CarFleet",
        Item: {
          id: 123,
          name: "AAA",
          vin: "ASD423E3D3RF5",
          make: "Mazda",
          model: "CX-5",
          year: "2019",
          fuelType: "petrol",
          type: "SUV",
          Position: {
            lat: 3.995,
            lon: 43.2221,
          },
          odometer: 43546,
          fuel: 33.4,
          battery: 12.7,
        },
      };
      console.log("Adding a new item...");
      this.docClient.put(dbParams, function (err, data) {
        if (err) {
          console.error(
            "Unable to add item. Error JSON:",
            JSON.stringify(err, null, 2)
          );
        } else {
          console.log("Added item:", JSON.stringify(data, null, 2));
          return res.status(200).json({ message: "Post request successfull" });
        }
      });
    });

    app.get("/api/car/:id", (req: Request, res: Response) => {
      let carID = req.params.id;
      console.log("request received, fetching car ", req.params.id);
      let dbParams = {
        TableName: "CarFleet",
        Key: {
          id: {
            N: carID,
          },
        },
      };
      this.dynamodb.getItem(dbParams, (err, data) => {
        if (err) {
          console.error("No car found", err);
          res.json(data);
        } else {
          console.log("car data => ", data);
          res.json(data);
        }
      });
    });

    app.delete("/api/car/:id", (req: Request, res: Response) => {
      let carID = req.params.id;
      console.log(`request received, deleting car ${typeof carID}`);
      let dbParams = {
        TableName: "CarFleet",
        Key: {
          id: {
            N: carID,
          },
        },
      };
      console.log("Attempting a conditional delete...");
      this.docClient.delete(dbParams, function (err, data) {
        if (err) {
          console.error(
            "Unable to delete item. Error JSON:",
            JSON.stringify(err, null, 2)
          );
          res.status(400).send(err.message);
        } else {
          console.log("DeleteItem succeeded:", JSON.stringify(data, null, 2));
        }
      });
    });
  }
}
