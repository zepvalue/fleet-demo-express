export class carController {
  public create_car(req: Request, res: Response) {
    console.log("create car");
  }
  public get_car(req: Request, res: Response) {
    console.log("get car");
  }
  public delete_car(req: Request, res: Response) {
    console.log("delete car");
  }
}
